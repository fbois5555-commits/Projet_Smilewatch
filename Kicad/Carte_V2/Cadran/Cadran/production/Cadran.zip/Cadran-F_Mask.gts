G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*
G04 #@! TF.CreationDate,2026-11-11T18:00:54+01:00*
G04 #@! TF.ProjectId,Cadran,43616472-616e-42e6-9b69-6361645f7063,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-11-11 18:00:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
